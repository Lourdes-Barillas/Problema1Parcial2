package Vehiculo;

public interface Impuesto {
    public double calculoImpuesto(int ref);
}
